

set -ex



py.test -v tests
exit 0
