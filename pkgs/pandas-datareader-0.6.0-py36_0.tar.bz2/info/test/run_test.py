print("import: 'pandas_datareader'")
import pandas_datareader

print("import: 'pandas_datareader.compat'")
import pandas_datareader.compat

print("import: 'pandas_datareader.google'")
import pandas_datareader.google

print("import: 'pandas_datareader.iex'")
import pandas_datareader.iex

print("import: 'pandas_datareader.io'")
import pandas_datareader.io

print("import: 'pandas_datareader.mstar'")
import pandas_datareader.mstar

print("import: 'pandas_datareader.tests'")
import pandas_datareader.tests

print("import: 'pandas_datareader.tests.google'")
import pandas_datareader.tests.google

print("import: 'pandas_datareader.tests.io'")
import pandas_datareader.tests.io

print("import: 'pandas_datareader.tests.mstar'")
import pandas_datareader.tests.mstar

print("import: 'pandas_datareader.tests.yahoo'")
import pandas_datareader.tests.yahoo

print("import: 'pandas_datareader.yahoo'")
import pandas_datareader.yahoo

