

set -ex



test -f $PREFIX/lib/libparquet.so
test -f $PREFIX/include/parquet/api/reader.h
exit 0
