print("import: 'nbpresent'")
import nbpresent

