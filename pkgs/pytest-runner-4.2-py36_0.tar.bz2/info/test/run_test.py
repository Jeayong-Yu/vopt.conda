print("import: 'ptr'")
import ptr

