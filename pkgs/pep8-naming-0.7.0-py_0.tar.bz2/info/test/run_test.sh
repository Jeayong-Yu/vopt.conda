

set -ex



flake8 --version | grep naming:
exit 0
