

set -ex



f2py -h
conda inspect linkages -p $PREFIX numpy
exit 0
