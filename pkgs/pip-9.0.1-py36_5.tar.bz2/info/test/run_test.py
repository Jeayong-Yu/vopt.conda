print("import: u'pip'")
import pip

