print("import: u'_CVXcanon'")
import _CVXcanon

print("import: u'CVXcanon'")
import CVXcanon

