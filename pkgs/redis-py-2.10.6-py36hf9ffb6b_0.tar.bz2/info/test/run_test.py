print("import: 'redis'")
import redis

