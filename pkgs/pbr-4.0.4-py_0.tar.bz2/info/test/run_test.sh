

set -ex



pbr --help
exit 0
