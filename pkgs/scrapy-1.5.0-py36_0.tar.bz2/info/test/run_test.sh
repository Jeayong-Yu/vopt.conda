

set -ex



scrapy bench
exit 0
