print("import: 'scrapy'")
import scrapy

print("import: 'scrapy.commands'")
import scrapy.commands

print("import: 'scrapy.contracts'")
import scrapy.contracts

print("import: 'scrapy.contrib'")
import scrapy.contrib

print("import: 'scrapy.contrib.downloadermiddleware'")
import scrapy.contrib.downloadermiddleware

print("import: 'scrapy.exporters'")
import scrapy.exporters

print("import: 'scrapy.linkextractors'")
import scrapy.linkextractors

print("import: 'scrapy.loader'")
import scrapy.loader

print("import: 'scrapy.pipelines'")
import scrapy.pipelines

print("import: 'scrapy.contrib.spidermiddleware'")
import scrapy.contrib.spidermiddleware

print("import: 'scrapy.contrib_exp'")
import scrapy.contrib_exp

print("import: 'scrapy.contrib_exp.downloadermiddleware'")
import scrapy.contrib_exp.downloadermiddleware

print("import: 'scrapy.core'")
import scrapy.core

print("import: 'scrapy.core.downloader'")
import scrapy.core.downloader

print("import: 'scrapy.core.downloader.handlers'")
import scrapy.core.downloader.handlers

print("import: 'scrapy.downloadermiddlewares'")
import scrapy.downloadermiddlewares

print("import: 'scrapy.extensions'")
import scrapy.extensions

print("import: 'scrapy.http'")
import scrapy.http

print("import: 'scrapy.http.request'")
import scrapy.http.request

print("import: 'scrapy.http.response'")
import scrapy.http.response

print("import: 'scrapy.linkextractors'")
import scrapy.linkextractors

print("import: 'scrapy.loader'")
import scrapy.loader

print("import: 'scrapy.pipelines'")
import scrapy.pipelines

print("import: 'scrapy.selector'")
import scrapy.selector

print("import: 'scrapy.settings'")
import scrapy.settings

print("import: 'scrapy.spidermiddlewares'")
import scrapy.spidermiddlewares

print("import: 'scrapy.spiders'")
import scrapy.spiders

print("import: 'scrapy.utils'")
import scrapy.utils

print("import: 'scrapy.xlib'")
import scrapy.xlib

