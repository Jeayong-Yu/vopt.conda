print("import: u'scrapy'")
import scrapy

print("import: u'scrapy.commands'")
import scrapy.commands

print("import: u'scrapy.contracts'")
import scrapy.contracts

print("import: u'scrapy.contrib'")
import scrapy.contrib

print("import: u'scrapy.contrib.downloadermiddleware'")
import scrapy.contrib.downloadermiddleware

print("import: u'scrapy.exporters'")
import scrapy.exporters

print("import: u'scrapy.linkextractors'")
import scrapy.linkextractors

print("import: u'scrapy.loader'")
import scrapy.loader

print("import: u'scrapy.pipelines'")
import scrapy.pipelines

print("import: u'scrapy.contrib.spidermiddleware'")
import scrapy.contrib.spidermiddleware

print("import: u'scrapy.contrib_exp'")
import scrapy.contrib_exp

print("import: u'scrapy.contrib_exp.downloadermiddleware'")
import scrapy.contrib_exp.downloadermiddleware

print("import: u'scrapy.core'")
import scrapy.core

print("import: u'scrapy.core.downloader'")
import scrapy.core.downloader

print("import: u'scrapy.core.downloader.handlers'")
import scrapy.core.downloader.handlers

print("import: u'scrapy.downloadermiddlewares'")
import scrapy.downloadermiddlewares

print("import: u'scrapy.extensions'")
import scrapy.extensions

print("import: u'scrapy.http'")
import scrapy.http

print("import: u'scrapy.http.request'")
import scrapy.http.request

print("import: u'scrapy.http.response'")
import scrapy.http.response

print("import: u'scrapy.linkextractors'")
import scrapy.linkextractors

print("import: u'scrapy.loader'")
import scrapy.loader

print("import: u'scrapy.pipelines'")
import scrapy.pipelines

print("import: u'scrapy.selector'")
import scrapy.selector

print("import: u'scrapy.settings'")
import scrapy.settings

print("import: u'scrapy.spidermiddlewares'")
import scrapy.spidermiddlewares

print("import: u'scrapy.spiders'")
import scrapy.spiders

print("import: u'scrapy.utils'")
import scrapy.utils

print("import: u'scrapy.xlib'")
import scrapy.xlib

