#!/bin/bash

cp "${RECIPE_DIR}"/EULA.txt .

mkdir -p ${STDLIB_DIR}
if [[ $(uname) == Linux  ]]; then TP="${ARCH}-bit"; fi
if [[ $(uname) == Darwin ]]; then TP="64-bit"; fi
echo "Anaconda ${PKG_VERSION} (${TP})" > ${STDLIB_DIR}/version.txt
