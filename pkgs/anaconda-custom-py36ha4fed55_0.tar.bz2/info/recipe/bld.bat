rd /s /q %STDLIB_DIR%
mkdir %STDLIB_DIR%

@echo off
echo Anaconda %PKG_VERSION% (%ARCH%-bit)> %STDLIB_DIR%\version.txt
if errorlevel 1 exit 1
