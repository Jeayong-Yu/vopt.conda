

set -ex



coverage --help
exit 0
