print("import: u'hyperlink'")
import hyperlink

print("import: u'hyperlink.test'")
import hyperlink.test

