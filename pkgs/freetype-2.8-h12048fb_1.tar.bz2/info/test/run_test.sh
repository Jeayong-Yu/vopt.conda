

set -ex



freetype-config --version
conda inspect linkages -p $PREFIX freetype
conda inspect objects -p $PREFIX freetype
exit 0
