

set -ex



test -f "${SP_DIR}/flask_restplus/static/swagger-ui.js"
test -f "${SP_DIR}/flask_restplus/static/swagger-ui.css"
exit 0
