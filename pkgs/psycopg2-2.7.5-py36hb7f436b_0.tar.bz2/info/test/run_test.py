print("import: 'psycopg2'")
import psycopg2

print("import: 'psycopg2._psycopg'")
import psycopg2._psycopg

