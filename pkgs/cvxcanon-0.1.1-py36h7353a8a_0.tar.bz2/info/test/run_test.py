print("import: '_CVXcanon'")
import _CVXcanon

print("import: 'CVXcanon'")
import CVXcanon

