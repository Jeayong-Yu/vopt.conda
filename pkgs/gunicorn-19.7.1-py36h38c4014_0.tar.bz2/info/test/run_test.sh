

set -ex



gunicorn --help
gunicorn_paster --help
exit 0
