print("import: 'simplejson'")
import simplejson

print("import: 'simplejson.tests'")
import simplejson.tests

