print("import: u'simplejson'")
import simplejson

print("import: u'simplejson.tests'")
import simplejson.tests

