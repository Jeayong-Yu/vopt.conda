

set -ex



flake8 src/flake8 tests/integration tests/unit setup.py
exit 0
