

set -ex



kernprof --help
python -m kernprof --help
python -m line_profiler --help
exit 0
