print("import: 'kernprof'")
import kernprof

print("import: 'line_profiler'")
import line_profiler

print("import: 'line_profiler_py35'")
import line_profiler_py35

