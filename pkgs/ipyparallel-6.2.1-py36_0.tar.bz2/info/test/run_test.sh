

set -ex



ipcluster -h
ipengine -h
ipcontroller -h
exit 0
