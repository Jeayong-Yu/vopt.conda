#  tests for ipyparallel-6.2.1-py36_0 (this is a generated file);
print('===== testing package: ipyparallel-6.2.1-py36_0 =====');
print('running run_test.py');
#  --- run_test.py (begin) ---
#!/usr/bin/env python

import sys
from subprocess import check_output, STDOUT

def sh(cmd):
    out = check_output(cmd, stderr=STDOUT)
    return out.decode('utf8', 'replace')

# verify extension enabling
nbextensions = sh([sys.executable, '-m', 'jupyter', 'nbextension', 'list'])
print(nbextensions)
assert 'ipyparallel' in nbextensions

serverextensions = sh([sys.executable, '-m', 'jupyter', 'serverextension', 'list'])
print(serverextensions)
assert 'ipyparallel' in serverextensions
#  --- run_test.py (end) ---

print('===== ipyparallel-6.2.1-py36_0 OK =====');
print("import: 'ipyparallel'")
import ipyparallel

print("import: 'ipyparallel.apps'")
import ipyparallel.apps

print("import: 'ipyparallel.client'")
import ipyparallel.client

print("import: 'ipyparallel.controller'")
import ipyparallel.controller

print("import: 'ipyparallel.engine'")
import ipyparallel.engine

print("import: 'ipyparallel.serialize'")
import ipyparallel.serialize

