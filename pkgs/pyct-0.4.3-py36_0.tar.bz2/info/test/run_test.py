print("import: 'pyct'")
import pyct

print("import: 'pyct.cmd'")
import pyct.cmd

